package IndividualnoZad;
public abstract class EProizvod {
    protected String opis;
    protected String sifra;
    protected double uvoznaCijena;

    public EProizvod(String opis, String sifra, double uvoznaCijena) {
        this.opis = opis;
        this.sifra = sifra;
        this.uvoznaCijena = uvoznaCijena;
    }

    public abstract double maloprodajnaCijena();

    public String getTip() {
        return sifra.substring(0, 2);
    }

    public String toString() {
        return String.format("Opis: %s | Šifra: %s | Uvozna cijena: %.2f | Maloprodajna cijena: %.2f",
                opis, sifra, uvoznaCijena, maloprodajnaCijena());
    }
}



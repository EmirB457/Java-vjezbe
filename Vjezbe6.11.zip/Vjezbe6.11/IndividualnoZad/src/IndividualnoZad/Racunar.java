package IndividualnoZad;
public class Racunar extends EProizvod {
    private String procesor;
    private int memorija;

    public Racunar(String opis, String sifra, double uvoznaCijena, String procesor, int memorija) {
        super(opis, sifra, uvoznaCijena);
        this.procesor = procesor;
        this.memorija = memorija;
    }

    @Override
    public double maloprodajnaCijena() {
        double cijena = uvoznaCijena * 1.05;
        cijena *= 1.05;
        return cijena;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Procesor: %s | Memorija: %dGB", procesor, memorija);
    }
}



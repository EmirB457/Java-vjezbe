package IndividualnoZad;
public class TVUredjaj extends EProizvod {
    private double velicinaEkrana;

    public TVUredjaj(String opis, String sifra, double uvoznaCijena, double velicinaEkrana) {
        super(opis, sifra, uvoznaCijena);
        this.velicinaEkrana = velicinaEkrana;
    }

    @Override
    public double maloprodajnaCijena() {
        double cijena = uvoznaCijena * 1.05;
        if (velicinaEkrana > 65.0) {
            cijena *= 1.10;
        }
        return cijena;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Ekran: %.1f inča", velicinaEkrana);
    }
}



package IndividualnoZad;
import java.util.*;

public class ElektronskiSistem {
    public static List<EProizvod> filtrirajPoTipu(List<EProizvod> lista, String tip) { 
        List<EProizvod> rezultat = new ArrayList<>();
        for (EProizvod p : lista) {
            if (p.getTip().equalsIgnoreCase(tip)) {
                rezultat.add(p);
            }
        }
        return rezultat;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<EProizvod> proizvodi = new ArrayList<>();

        while (true) {
            System.out.println("\n--- MENI ---");
            System.out.println("1. Unos uređaja");
            System.out.println("2. Pregled svih uređaja sa maloprodajnom cijenom");
            System.out.println("3. Pregled uređaja određenog tipa");
            System.out.println("0. Izlaz");
            System.out.print("Izbor: ");
            int izbor = sc.nextInt();
            sc.nextLine();

            switch (izbor) {
                case 1:
                    System.out.print("Opis: ");
                    String opis = sc.nextLine();
                    System.out.print("Šifra: ");
                    String sifra = sc.nextLine();
                    System.out.print("Uvozna cijena: ");
                    double cijena = sc.nextDouble();
                    sc.nextLine();

                    String tip = sifra.substring(0, 2).toUpperCase();
                    if (tip.equals("RA")) {
                        System.out.print("Procesor: ");
                        String proc = sc.nextLine();
                        System.out.print("Memorija (GB): ");
                        int mem = sc.nextInt();
                        proizvodi.add(new Racunar(opis, sifra, cijena, proc, mem));
                    } else if (tip.equals("TE")) {
                        System.out.print("Operativni sistem: ");
                        String os = sc.nextLine();
                        System.out.print("Veličina ekrana (inča): ");
                        double ekran = sc.nextDouble();
                        proizvodi.add(new Telefon(opis, sifra, cijena, os, ekran));
                    } else if (tip.equals("TV")) {
                        System.out.print("Veličina ekrana (inča): ");
                        double ekran = sc.nextDouble();
                        proizvodi.add(new TVUredjaj(opis, sifra, cijena, ekran));
                    } else {
                        System.out.println("Nepoznat tip uređaja.");
                    }
                    break;

                case 2:
                    for (EProizvod p : proizvodi) {
                        System.out.println(p);
                    }
                    break;

                case 3:
                    System.out.print("Unesite tip uređaja (RA, TE, TV): ");
                    String trazeniTip = sc.nextLine().toUpperCase();
                    List<EProizvod> filtrirani = filtrirajPoTipu(proizvodi, trazeniTip);
                    for (EProizvod p : filtrirani) {
                        System.out.println(p);
                    }
                    break;

                case 0:
                    System.out.println("Izlaz iz programa.");
                    return;

                default:
                    System.out.println("Nepoznata opcija.");
            }
        }
    }
}



package IndividualnoZad;
public class Telefon extends EProizvod {
    private String operativniSistem;
    private double velicinaEkrana;

    public Telefon(String opis, String sifra, double uvoznaCijena, String operativniSistem, double velicinaEkrana) {
        super(opis, sifra, uvoznaCijena);
        this.operativniSistem = operativniSistem;
        this.velicinaEkrana = velicinaEkrana;
    }

    @Override
    public double maloprodajnaCijena() {
        double cijena = uvoznaCijena * 1.05;
        if (velicinaEkrana > 6.0) {
            cijena *= 1.03;
        }
        return cijena;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | OS: %s | Ekran: %.1f inča", operativniSistem, velicinaEkrana);
    }
}



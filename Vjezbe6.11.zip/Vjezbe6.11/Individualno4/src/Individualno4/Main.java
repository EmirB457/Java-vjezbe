package Individualno4;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Restoran r = new Restoran("Ulix", "City Kvart", "ME123456");

        r.dodajZaposlenog(new Konobar("K01", "Emir", "Balijagic", 5.5, 40, 5));
        r.dodajZaposlenog(new Kuvar("K02", "Danis", "Numanovic", 7.0, 38));
        r.dodajZaposlenog(new Menadzer("M01", "Petar", "Raicevic", 10.0, 35, 200));
        r.dodajZaposlenog(new Konobar("K03", "Semir", "Bralic", 6.0, 42, 0));
        r.dodajZaposlenog(new Kuvar("K04", "Edis", "Muric", 6.5, 40));

        List<ObracunPlate> obracuni = r.generisiObracun("Novembar", 2025);

        System.out.printf("%-5s %-15s %-10s %-6s %-25s %-10s\n",
            "ID", "Ime i Prezime", "Tip", "Sati", "Napomena", "Plata");

        for (ObracunPlate o : obracuni)
            o.ispisi();

        System.out.printf("\nUkupan trosak plata: %.2f EUR\n", r.ukupniTrosak(obracuni));
    }
}

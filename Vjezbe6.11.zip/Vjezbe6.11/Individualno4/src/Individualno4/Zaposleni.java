package Individualno4;
public abstract class Zaposleni {
    private String id;
    private String ime;
    private String prezime;
    private double plataPoSatu;
    private int ukupanBrojSati;

    public Zaposleni(String id, String ime, String prezime, double plataPoSatu, int ukupanBrojSati) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.plataPoSatu = plataPoSatu;
        this.ukupanBrojSati = ukupanBrojSati;
    }

    public abstract double izracunajPlatu();
    public abstract String getTip();

    public String getId() { return id; }
    public String getImePrezime() { return ime + " " + prezime; }
    public double getPlataPoSatu() { return plataPoSatu; }
    public int getUkupanBrojSati() { return ukupanBrojSati; }

    public void setUkupanBrojSati(int sati) { this.ukupanBrojSati = sati; }
    public void setPlataPoSatu(double plata) { this.plataPoSatu = plata; }
}



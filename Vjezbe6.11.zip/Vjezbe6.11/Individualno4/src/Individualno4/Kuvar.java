package Individualno4;
public class Kuvar extends Zaposleni {
    public Kuvar(String id, String ime, String prezime, double plataPoSatu, int ukupanBrojSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
    }

    @Override
    public double izracunajPlatu() {
        return 1500 + 4 * getUkupanBrojSati() * getPlataPoSatu();
    }

    @Override
    public String getTip() { return "Kuvar"; }
}



package Individualno4;
import java.util.*;

public class Restoran {
    private String naziv;
    private String adresa;
    private String pib;
    private List<Zaposleni> zaposleni;

    public Restoran(String naziv, String adresa, String pib) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.pib = pib;
        this.zaposleni = new ArrayList<>();
    }

    public void dodajZaposlenog(Zaposleni z) {
        zaposleni.add(z);
    }

    public void ukloniZaposlenog(String id) {
        zaposleni.removeIf(z -> z.getId().equals(id));
    }

    public Zaposleni nadjiZaposlenog(String id) {
        for (Zaposleni z : zaposleni)
            if (z.getId().equals(id)) return z;
        return null;
    }

    public List<ObracunPlate> generisiObracun(String mjesec, int godina) {
        List<ObracunPlate> obracuni = new ArrayList<>();
        for (Zaposleni z : zaposleni) {
            double iznos = z.izracunajPlatu();
            String napomena = "";
            if (z instanceof Konobar konobar && konobar.getPrekovremeniSati() > 0)
                napomena = "uracunat prekovremeni rad";
            else if (z instanceof Menadzer menadzer && menadzer.getBonus() > 0)
                napomena = "bonus: " + menadzer.getBonus() + " EUR";

            obracuni.add(new ObracunPlate(mjesec, godina, z, iznos, napomena));
        }
        return obracuni;
    }

    public double ukupniTrosak(List<ObracunPlate> obracuni) {
        return obracuni.stream().mapToDouble(ObracunPlate::getIznos).sum();
    }
}


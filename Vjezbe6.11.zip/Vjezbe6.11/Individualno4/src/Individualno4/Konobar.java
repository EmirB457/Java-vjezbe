package Individualno4;
public class Konobar extends Zaposleni {
    private int prekovremeniSati;

    public Konobar(String id, String ime, String prezime, double plataPoSatu, int ukupanBrojSati, int prekovremeniSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.prekovremeniSati = prekovremeniSati;
    }

    @Override
    public double izracunajPlatu() {
        double redovni = 4 * getUkupanBrojSati() * getPlataPoSatu();
        double prekovremeni = 4 * prekovremeniSati * getPlataPoSatu() * 1.2;
        return redovni + prekovremeni;
    }

    @Override
    public String getTip() { return "Konobar"; }

    public int getPrekovremeniSati() { return prekovremeniSati; }
    public void setPrekovremeniSati(int sati) { this.prekovremeniSati = sati; }
}



package Individualno4;
public class ObracunPlate {
    private String mjesec;
    private int godina;
    private Zaposleni zaposleni;
    private double iznos;
    private String napomena;

    public ObracunPlate(String mjesec, int godina, Zaposleni zaposleni, double iznos, String napomena) {
        this.mjesec = mjesec;
        this.godina = godina;
        this.zaposleni = zaposleni;
        this.iznos = iznos;
        this.napomena = napomena;
    }

    public void ispisi() {
        System.out.printf("%-5s %-15s %-10s %-6d %-25s %-10.2f\n", // formatirani ispis
            zaposleni.getId(),
            zaposleni.getImePrezime(),
            zaposleni.getTip(),
            zaposleni.getUkupanBrojSati(),
            napomena,
            iznos
        );
    }

    public double getIznos() { return iznos; }
}


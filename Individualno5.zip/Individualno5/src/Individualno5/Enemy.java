package Individualno5;


public class Enemy extends GameObject implements Attacker {
    protected String type;
    protected int damage, health;

    public Enemy(int x, int y, Collidable collider, String type, int damage, int health) {
        super(x, y, collider);
        setType(type);
        setDamage(damage);
        setHealth(health);
    }

    public void setType(String type) {
        type = type.trim();
        if (type.isEmpty())
            throw new IllegalArgumentException("Tip neprijatelja ne može biti prazan.");
        this.type = type;
    }

    public void setDamage(int damage) {
        if (damage < 0 || damage > 100)
            throw new IllegalArgumentException("Damage mora biti između 0 i 100.");
        this.damage = damage;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 150) // proširen limit
            throw new IllegalArgumentException("Health mora biti između 0 i 150.");
        this.health = health;
    }

    public int getEffectiveDamage() { return damage; }

    public String getDisplayName() { return type; }

    public String toString() {
        String size = (collider instanceof RectangleCollider)
            ? ((RectangleCollider) collider).getWidth() + "x" + ((RectangleCollider) collider).getHeight()
            : "Circle@" + ((CircleCollider) collider).getRadius();
        return "Enemy[" + type + "] @ (" + getX() + "," + getY() + ") " + size + " DMG=" + damage + " HP=" + health;
    }
}




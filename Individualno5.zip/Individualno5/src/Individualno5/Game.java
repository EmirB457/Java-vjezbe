package Individualno5;
import java.util.*;

public class Game {
    private Player player;
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private ArrayList<String> eventLog = new ArrayList<>();

    public Game(Player player) {
        this.player = player;
    }

    public void addEnemy(Enemy e) {
        if (e == null) throw new IllegalArgumentException("Neprijatelj ne može biti null.");
        enemies.add(e);
        eventLog.add("ADDED: " + e.getDisplayName());
    }

    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        if (p == null || e == null)
            throw new IllegalArgumentException("Player ili Enemy je null.");
        int oldHP = p.getHealth();
        int dmg = e.getEffectiveDamage();
        int newHP = Math.max(0, oldHP - dmg);
        p.setHealth(newHP);
        eventLog.add("HIT: Player by " + e.getDisplayName() + " for " + dmg +
                     " -> HP " + oldHP + " -> " + newHP);
    }

    public List<Enemy> findByType(String query) {
        query = query.toLowerCase();
        List<Enemy> result = new ArrayList<>();
        for (Enemy e : enemies) {
            if (e.getDisplayName().toLowerCase().contains(query))
                result.add(e);
        }
        return result;
    }

    public List<Enemy> collidingWithPlayer() {
        List<Enemy> result = new ArrayList<>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e))
                result.add(e);
        }
        return result;
    }

    public void resolveCollisions() {
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                decreaseHealth(player, e);
            }
        }
    }

    public List<String> getEventLog() {
        return eventLog;
    }

    public static Enemy parseEnemy(String line) {
        try {
            String[] parts = line.split(";");
            if (parts.length != 5)
                throw new IllegalArgumentException("Neispravan format linije: " + line);

            String type = parts[0].trim();
            String[] pos = parts[1].split(",");
            int x = Integer.parseInt(pos[0].trim());
            int y = Integer.parseInt(pos[1].trim());

            String[] size = parts[2].split("x");
            int w = Integer.parseInt(size[0].trim());
            int h = Integer.parseInt(size[1].trim());

            int damage = Integer.parseInt(parts[3].trim());
            String kind = parts[4].trim().toLowerCase();

            Collidable collider = new RectangleCollider(x, y, w, h);

            if (kind.equals("boss")) {
                return new BossEnemy(x, y, collider, type, damage, 120);
            } else {
                return new MeleeEnemy(x, y, collider, type, damage, 60);
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Greška u parsiranju brojeva: " + e.getMessage());
        }
    }
}


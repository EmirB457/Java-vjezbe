package Individualno5;
public class Player extends GameObject {
    private String name;
    private int health;

    public Player(int x, int y, Collidable collider, String name, int health) {
        super(x, y, collider);
        setName(name);
        setHealth(health);
    }

    public void setName(String name) {
        name = name.trim().replaceAll("\\s+", " ");
        String[] parts = name.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty())
                sb.append(Character.toUpperCase(part.charAt(0)))
                  .append(part.substring(1).toLowerCase()).append(" ");
        }
        name = sb.toString().trim();
        if (name.isEmpty())
            throw new IllegalArgumentException("Ime ne može biti prazno.");
        this.name = name;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100)
            throw new IllegalArgumentException("Health mora biti između 0 i 100.");
        this.health = health;
    }

    public int getHealth() { return health; }

    public String getDisplayName() { return name; }

    public String toString() {
        String size = (collider instanceof RectangleCollider)
            ? ((RectangleCollider) collider).getWidth() + "x" + ((RectangleCollider) collider).getHeight()
            : "Circle@" + ((CircleCollider) collider).getRadius();
        return "Player[" + name + "] @ (" + getX() + "," + getY() + ") " + size + " HP=" + health;
    }
}



package Individualno5;
public abstract class GameObject {
    private int x, y;
    protected Collidable collider;

    public GameObject(int x, int y, Collidable collider) {
        this.x = x;
        this.y = y;
        if (collider == null)
            throw new IllegalArgumentException("Collider ne može biti null.");
        this.collider = collider;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }

    public boolean intersects(GameObject other) {
        return collider.intersects(other.collider);
    }

    public abstract String getDisplayName();

    public String toString() {
        return "GameObject@" + "(" + x + "," + y + ")";
    }
}



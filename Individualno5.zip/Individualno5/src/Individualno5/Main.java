package Individualno5;


public class Main {
    public static void main(String[] args) {
       
        Collidable playerCollider = new RectangleCollider(10, 5, 32, 32);
        Player player = new Player(10, 5, playerCollider, "peTar petrovic", 85);

      
        Game game = new Game(player);

        
        Collidable goblinCollider = new CircleCollider(12, 5, 8);
        Enemy goblin = new MeleeEnemy(12, 5, goblinCollider, "Goblin", 20, 60);
        game.addEnemy(goblin);

       
        Enemy boss = Game.parseEnemy("Goblin King; 12,5;32x32;25;boss");
        game.addEnemy(boss);

       
        System.out.println("Svi neprijatelji:");
        for (Enemy e : game.findByType("")) {
            System.out.println(e);
        }

        
        System.out.println("\nNeprijatelji koji sadrže 'gob':");
        for (Enemy e : game.findByType("gob")) {
            System.out.println(e);
        }

       
        System.out.println("\nKolizije sa igračem:");
        for (Enemy e : game.collidingWithPlayer()) {
            System.out.println("Kolizija sa: " + e.getDisplayName());
        }

       
        System.out.println("\nStanje igrača prije:");
        System.out.println(player);

      
        game.resolveCollisions();

      
        System.out.println("\nStanje igrača poslije:");
        System.out.println(player);

      
        System.out.println("\nDnevnik događaja:");
        for (String log : game.getEventLog()) {
            System.out.println(log);
        }
    }
}

       
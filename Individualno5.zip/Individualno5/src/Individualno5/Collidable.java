package Individualno5;

public interface Collidable {
    boolean intersects(Collidable other);
}

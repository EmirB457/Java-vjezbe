package Individualno5;
public interface Attacker {
    int getEffectiveDamage();
}



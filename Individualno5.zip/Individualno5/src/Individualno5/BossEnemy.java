package Individualno5;
public class BossEnemy extends Enemy {
    public BossEnemy(int x, int y, Collidable collider, String type, int damage, int health) {
        super(x, y, collider, type, damage, health);
    }

    public int getEffectiveDamage() {
        return damage * 2;
    }

    public String toString() {
        String size = (collider instanceof RectangleCollider)
            ? ((RectangleCollider) collider).getWidth() + "x" + ((RectangleCollider) collider).getHeight()
            : "Circle@" + ((CircleCollider) collider).getRadius();
        return "BossEnemy[" + type + "] @ (" + getX() + "," + getY() + ") " + size + " DMG=" + damage + "x2 HP=" + health;
    }
}


package Individualno5;
public class CircleCollider implements Collidable {
    private int x, y, radius;

    public CircleCollider(int x, int y, int radius) {
        if (radius <= 0)
            throw new IllegalArgumentException("Poluprečnik mora biti pozitivan.");
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public boolean intersects(Collidable other) {
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;
            int dx = x - c.x;
            int dy = y - c.y;
            int distanceSq = dx * dx + dy * dy;
            int radiusSum = radius + c.radius;
            return distanceSq <= radiusSum * radiusSum;
        } else if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;
            int closestX = clamp(x, r.getX(), r.getX() + r.getWidth());
            int closestY = clamp(y, r.getY(), r.getY() + r.getHeight());
            int dx = x - closestX;
            int dy = y - closestY;
            return dx * dx + dy * dy <= radius * radius;
        }
        return false;
    }

    private int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getRadius() { return radius; }
}
